-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Aug 20, 2020 at 05:38 PM
-- Server version: 5.7.23
-- PHP Version: 7.0.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yin`
--

-- --------------------------------------------------------

--
-- Table structure for table `dayscore`
--

CREATE TABLE `dayscore` (
  `id` int(2) NOT NULL,
  `dayscore` varchar(14) NOT NULL,
  `created_datetime` datetime NOT NULL,
  `modified_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dayscore`
--

INSERT INTO `dayscore` (`id`, `dayscore`, `created_datetime`, `modified_datetime`) VALUES
(1, 'Stressed-out', '2018-01-31 14:33:00', '2018-01-31 14:33:00'),
(2, 'Frustrated', '2018-01-31 14:33:00', '2018-01-31 14:33:00'),
(3, 'Depressed', '2018-01-31 14:33:00', '2018-01-31 14:33:00'),
(4, 'Exhausted', '2018-01-31 14:33:00', '2018-01-31 14:33:00'),
(5, 'Normal', '2018-01-31 14:33:00', '2018-01-31 14:33:00'),
(6, 'Good', '2018-01-31 14:33:00', '2018-01-31 14:33:00'),
(7, 'Amazing', '2018-01-31 14:33:00', '2018-01-31 14:33:00');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `image_name` varchar(72) NOT NULL,
  `image_path` varchar(72) NOT NULL,
  `created_datetime` datetime NOT NULL,
  `modified_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `id` int(122) UNSIGNED NOT NULL,
  `user_type` varchar(250) DEFAULT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`id`, `user_type`, `data`) VALUES
(1, 'Member', '{\"users\":{\"own_create\":\"1\",\"own_read\":\"1\",\"own_update\":\"1\",\"own_delete\":\"1\"}}'),
(2, 'admin', '{\"users\":{\"own_create\":\"1\",\"own_read\":\"1\",\"own_update\":\"1\",\"own_delete\":\"1\",\"all_create\":\"1\",\"all_read\":\"1\",\"all_update\":\"1\",\"all_delete\":\"1\"}}');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(122) UNSIGNED NOT NULL,
  `keys` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `keys`, `value`) VALUES
(1, 'website', 'Year In Pixels'),
(2, 'logo', ''),
(3, 'favicon', ''),
(4, 'SMTP_EMAIL', 'alerts@imsuresh.com'),
(5, 'HOST', 'smtp.zoho.com'),
(6, 'PORT', '80'),
(7, 'SMTP_SECURE', '465'),
(8, 'SMTP_PASSWORD', 'Tom79Cat]Jery'),
(9, 'mail_setting', 'php_mailer'),
(10, 'company_name', 'Year In Pixels'),
(11, 'crud_list', 'users,User'),
(12, 'EMAIL', ''),
(13, 'UserModules', 'yes'),
(14, 'register_allowed', '1'),
(15, 'email_invitation', '1'),
(16, 'admin_approval', '0'),
(17, 'user_type', '[\"admin\"]');

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE `tag` (
  `id` int(11) NOT NULL,
  `Tag` varchar(50) NOT NULL,
  `created_datetime` datetime NOT NULL,
  `modified_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` int(121) UNSIGNED NOT NULL,
  `module` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `template_name` varchar(255) DEFAULT NULL,
  `html` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id`, `module`, `code`, `template_name`, `html`) VALUES
(1, 'forgot_pass', 'forgot_password', 'Forgot password', '<html xmlns=\"http://www.w3.org/1999/xhtml\"><head>\r\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n  <style type=\"text/css\" rel=\"stylesheet\" media=\"all\">\r\n    /* Base ------------------------------ */\r\n    *:not(br):not(tr):not(html) {\r\n      font-family: Arial, \'Helvetica Neue\', Helvetica, sans-serif;\r\n      -webkit-box-sizing: border-box;\r\n      box-sizing: border-box;\r\n    }\r\n    body {\r\n      \r\n    }\r\n    a {\r\n      color: #3869D4;\r\n    }\r\n\r\n\r\n    /* Masthead ----------------------- */\r\n    .email-masthead {\r\n      padding: 25px 0;\r\n      text-align: center;\r\n    }\r\n    .email-masthead_logo {\r\n      max-width: 400px;\r\n      border: 0;\r\n    }\r\n    .email-footer {\r\n      width: 570px;\r\n      margin: 0 auto;\r\n      padding: 0;\r\n      text-align: center;\r\n    }\r\n    .email-footer p {\r\n      color: #AEAEAE;\r\n    }\r\n  \r\n    .content-cell {\r\n      padding: 35px;\r\n    }\r\n    .align-right {\r\n      text-align: right;\r\n    }\r\n\r\n    /* Type ------------------------------ */\r\n    h1 {\r\n      margin-top: 0;\r\n      color: #2F3133;\r\n      font-size: 19px;\r\n      font-weight: bold;\r\n      text-align: left;\r\n    }\r\n    h2 {\r\n      margin-top: 0;\r\n      color: #2F3133;\r\n      font-size: 16px;\r\n      font-weight: bold;\r\n      text-align: left;\r\n    }\r\n    h3 {\r\n      margin-top: 0;\r\n      color: #2F3133;\r\n      font-size: 14px;\r\n      font-weight: bold;\r\n      text-align: left;\r\n    }\r\n    p {\r\n      margin-top: 0;\r\n      color: #74787E;\r\n      font-size: 16px;\r\n      line-height: 1.5em;\r\n      text-align: left;\r\n    }\r\n    p.sub {\r\n      font-size: 12px;\r\n    }\r\n    p.center {\r\n      text-align: center;\r\n    }\r\n\r\n    /* Buttons ------------------------------ */\r\n    .button {\r\n      display: inline-block;\r\n      width: 200px;\r\n      background-color: #3869D4;\r\n      border-radius: 3px;\r\n      color: #ffffff;\r\n      font-size: 15px;\r\n      line-height: 45px;\r\n      text-align: center;\r\n      text-decoration: none;\r\n      -webkit-text-size-adjust: none;\r\n      mso-hide: all;\r\n    }\r\n    .button--green {\r\n      background-color: #22BC66;\r\n    }\r\n    .button--red {\r\n      background-color: #dc4d2f;\r\n    }\r\n    .button--blue {\r\n      background-color: #3869D4;\r\n    }\r\n  </style>\r\n</head>\r\n<body style=\"width: 100% !important;\r\n      height: 100%;\r\n      margin: 0;\r\n      line-height: 1.4;\r\n      background-color: #F2F4F6;\r\n      color: #74787E;\r\n      -webkit-text-size-adjust: none;\">\r\n  <table class=\"email-wrapper\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"\r\n    width: 100%;\r\n    margin: 0;\r\n    padding: 0;\">\r\n    <tbody><tr>\r\n      <td align=\"center\">\r\n        <table class=\"email-content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"width: 100%;\r\n      margin: 0;\r\n      padding: 0;\">\r\n          <!-- Logo -->\r\n\r\n          <tbody>\r\n          <!-- Email Body -->\r\n          <tr>\r\n            <td class=\"email-body\" width=\"100%\" style=\"width: 100%;\r\n    margin: 0;\r\n    padding: 0;\r\n    border-top: 1px solid #edeef2;\r\n    border-bottom: 1px solid #edeef2;\r\n    background-color: #edeef2;\">\r\n              <table class=\"email-body_inner\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\" style=\" width: 570px;\r\n    margin:  14px auto;\r\n    background: #fff;\r\n    padding: 0;\r\n    border: 1px outset rgba(136, 131, 131, 0.26);\r\n    box-shadow: 0px 6px 38px rgb(0, 0, 0);\r\n       \">\r\n                <!-- Body content -->\r\n                <thead style=\"background: #3869d4;\"><tr><th><div align=\"center\" style=\"padding: 15px; color: #000;\"><a href=\"{var_action_url}\" class=\"email-masthead_name\" style=\"font-size: 16px;\r\n      font-weight: bold;\r\n      color: #bbbfc3;\r\n      text-decoration: none;\r\n      text-shadow: 0 1px 0 white;\">{var_sender_name}</a></div></th></tr>\r\n                </thead>\r\n                <tbody><tr>\r\n                  <td class=\"content-cell\" style=\"padding: 35px;\">\r\n                    <h1>Hi {var_user_name},</h1>\r\n                    <p>You recently requested to reset your password for your {var_website_name} account. Click the button below to reset it.</p>\r\n                    <!-- Action -->\r\n                    <table class=\"body-action\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"\r\n      width: 100%;\r\n      margin: 30px auto;\r\n      padding: 0;\r\n      text-align: center;\">\r\n                      <tbody><tr>\r\n                        <td align=\"center\">\r\n                          <div>\r\n                            <!--[if mso]><v:roundrect xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" href=\"{{var_action_url}}\" style=\"height:45px;v-text-anchor:middle;width:200px;\" arcsize=\"7%\" stroke=\"f\" fill=\"t\">\r\n                              <v:fill type=\"tile\" color=\"#dc4d2f\" />\r\n                              <w:anchorlock/>\r\n                              <center style=\"color:#ffffff;font-family:sans-serif;font-size:15px;\">Reset your password</center>\r\n                            </v:roundrect><![endif]-->\r\n                            <a href=\"{var_varification_link}\" class=\"button button--red\" style=\"background-color: #dc4d2f;display: inline-block;\r\n      width: 200px;\r\n      background-color: #3869D4;\r\n      border-radius: 3px;\r\n      color: #ffffff;\r\n      font-size: 15px;\r\n      line-height: 45px;\r\n      text-align: center;\r\n      text-decoration: none;\r\n      -webkit-text-size-adjust: none;\r\n      mso-hide: all;\">Reset your password</a>\r\n                          </div>\r\n                        </td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                    <p>If you did not request a password reset, please ignore this email or reply to let us know.</p>\r\n                    <p>Thanks,<br>{var_sender_name} and the {var_website_name} Team</p>\r\n                   <!-- Sub copy -->\r\n                    <table class=\"body-sub\" style=\"margin-top: 25px;\r\n      padding-top: 25px;\r\n      border-top: 1px solid #EDEFF2;\">\r\n                      <tbody><tr>\r\n                        <td> \r\n                          <p class=\"sub\" style=\"font-size:12px;\">If you are having trouble clicking the password reset button, copy and paste the URL below into your web browser.</p>\r\n                          <p class=\"sub\"  style=\"font-size:12px;\"><a href=\"{var_varification_link}\">{var_varification_link}</a></p>\r\n                        </td>\r\n                      </tr>\r\n                    </tbody></table>\r\n                  </td>\r\n                </tr>\r\n              </tbody></table>\r\n            </td>\r\n          </tr>\r\n        </tbody></table>\r\n      </td>\r\n    </tr>\r\n  </tbody></table>\r\n\r\n\r\n</body></html>'),
(3, 'users', 'invitation', 'Invitation', '<p>Hello <strong>{var_user_email}</strong></p>\r\n\r\n<p>Click below link to register&nbsp;<br />\r\n{var_inviation_link}</p>\r\n\r\n<p>Thanks&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `users_id` int(121) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `var_key` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `is_deleted` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`users_id`, `user_id`, `var_key`, `status`, `is_deleted`, `name`, `password`, `email`, `profile_pic`, `user_type`) VALUES
(1, '1', '$2y$10$WgcupYMkcti/61rILg.7uujvhwKQm1VsjCptRKqdV4hraAsPNllpO', 'active', '0', 'admin', '$2y$10$lz0LqXn2rKIf6gqiTQZege1asw8Tuxqhla894In8cmzfs5mPxNDvS', 'phoenix.suresh@gmail.com', 'logo_1516851651.png', 'admin'),
(2, '1', NULL, 'active', '0', 'Suresh Manickam', '$2y$10$pyw1FG7wvrQk1TctLuNRG.bXpxoV4Tm51vrQbWLU7RE78bDoyKDri', 'sursoft@gmail.com', 'fullsizeoutput_1eb9_1516852356.jpeg', 'Member'),
(3, '1', NULL, 'active', '0', 'Suresh', '$2y$10$d.g2GLLz8uAKQZhc1jmV1ue6GVpfVJFycNY7ucXizA.C8hc6E93sS', 'suresh@pecko.com', 'user.png', 'Member'),
(0, NULL, '$2y$10$oLVRdrKI.JKIDzPCaD.dGu4eDm/Htwa0dSv9Gf48IzC5wvm5Io5FO', NULL, NULL, NULL, NULL, 'me@imsuresh.com', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `yin`
--

CREATE TABLE `yin` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `month` int(2) NOT NULL,
  `day` int(2) NOT NULL,
  `dayscore_id` int(2) NOT NULL,
  `comment` varchar(4096) NOT NULL,
  `tag_id` int(11) DEFAULT NULL,
  `did_workout` tinyint(1) NOT NULL,
  `pics` int(11) NOT NULL,
  `created_datetime` datetime NOT NULL,
  `modified_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Yin Table created with basic fields';

--
-- Dumping data for table `yin`
--

INSERT INTO `yin` (`id`, `user_id`, `date`, `year`, `month`, `day`, `dayscore_id`, `comment`, `tag_id`, `did_workout`, `pics`, `created_datetime`, `modified_datetime`) VALUES
(85, 3, 20180109, 2018, 1, 9, 7, 'WsPeuwkcIq7xA5jy7ugNzbZvMlmU7rmiUotUcEY3BIgBy30zgJsdnWBPU0qO+wPzvWlmT3cabLQtBic6/OkGj9Iw/1V5o0JweU1+qwca1OgLz4nLSzZ8eP4Imz2sIZcnjm27IdW3krk7iKCBP9kS1BUpGVbSC31ah2bseaRL8mA=', NULL, 0, 0, '2018-02-06 19:14:25', '2018-02-08 17:20:43'),
(86, 3, 20180110, 2018, 1, 10, 6, 'j0mxMEXTHa0vn/kv6JdaGYI1fxG9zmkkxeqek+NLxSfKhBlcpeBmCp/ffdrIrh82923l9ZIreShg2Aqal34VlQ==', NULL, 0, 0, '2018-02-08 20:22:26', '2018-02-08 20:22:26'),
(87, 3, 20180108, 2018, 1, 8, 3, 'j0mxMEXTHa0vn/kv6JdaGYI1fxG9zmkkxeqek+NLxSfKhBlcpeBmCp/ffdrIrh82923l9ZIreShg2Aqal34VlQ==', NULL, 0, 0, '2018-02-08 20:26:31', '2018-02-08 20:26:31'),
(88, 3, 20180107, 2018, 1, 7, 6, '3uFUhQYmG+tIo8AkyLgFJLe072v2t+gpZU23lSH/7M8=', NULL, 0, 0, '2018-02-08 20:29:01', '2018-02-08 20:29:01'),
(89, 3, 20180101, 2018, 1, 1, 7, 'BHNcDu8q2GxXpnRo6GTsLiTuXeMiueuIFaS8dJJ1vsU0P0ljCxM1hqyQ4MlW3L2kiVQmU0iWxm6d+KbZG/yRaELPjWfwS/mI/SXLWkIYHiS0zK5/rZN3Le13huUst/SWkvAr6x+GtIY0KC45qCnH0WbdluaW8EG9d0l+6BvEx1PnLnlW+dJPei4WSOVZy2zHIGGSnBpLY22DIePj2si50ht4nNVi9dciKZZElnX6PLiTCiXVEUrxcKveXE7dlNYRYli6cIcZv/aZTYkwoVzhQXXtNU0aFNVxulI4kXrONLhq79A4Y0S/7dZnwujmIl8TXyftR7Aza9BTKwPTJP33SOh8PbPRkMcP9oItISfz5kGp9dbhIl97uJfVLZreDGwJnEvQYoOOQWxNA8+y3gGGQWj2DrKeOuVgYMYngDI3ZHzbbDoPEqLjBAj2mW9qvOcIYZTr0W+dqCTKvnGibAg7WaSx/GaKWnrOXAhhToj/DVIkCLm6yNk24ERiHtiBJ1GVATgwuluu8L20f2IP50ENetrA//wgSWEpc9d1FANfl1vV10plpHki5aBsASHsoakL1EMi4RhuG9dacMBYb19QnLLCBTJaoW539JKJMnf+gvFzYT6zfrPHWwgptjuSXi7r7/62uN6//AKALGUicxmSrIVnb7WfC8uKFM7pEXbVtifcbxt2r4BAQsPGxXTMRSdnsQEItUUN4qvdNgRuRD202MKrU5We7e8wHfbICFdLE55AWZTFiePS9b7oiR33P88bKqRwrwDGerzGj/g5ygs2xIGTDbZ2qh3MK5K8IJIHBvAeiznVuPy185JKZOdJlaZOApsaso4gnRdutmMViOzRz2VnoJw8QfujglIc8enWAcrdUs2wAzyk5GlvZMdhdu0I55Z+h6zgnez3zNpmr39FYlOLGU7I1Mnnxj5CXGttUXs++b0l0Vz/Um3Nqc1siCzRGNhxxESKks8whPxgQToDax5Jx2Vd2D3jmTUa2HksapyxaI2KfRCruInL3cSzWQIQPJyrqu1+7DZPZ8Vs66VI2R81LEeyqqG8LUjsDJyANnrGgkM+QwmaX5aFjx24Fk9yjSGSdgsNimbLZiz/yc7fCoFPXcfUAgb9xJ/d10lRUKbHBICJxOVbakJQRaoc0KSmb0it2XRn06rVZsNtz84CzNCsYorbAO1Tct8ZDkZcVX4PpV6B0MkCX/xWbnIlMqshbxRnu3O2ITZ/ea48fJ1OvbYXPdGZeEp62NrpUZ9He4hV5iGwMRjahldVjWAJv+E4+KYvoYV8bGyu5BAwtlDMXy2SZ6JGHS6Qn9ck5/JEoHV0WN7qO4hALgEqbONlSE9Vx0U9JCysgoWUAoqp5lkTSF5Fxzw0dpvsWzvqfdpy8B9f020rBEw9vAxaFvxY0YouknQZK/syoV3pGgVNIKleswsyOb96iOut1yb05Jh7jrCicUsQMrAnyMpXye9QOFptJLnskBlh6YfTNELL1biLZqdBSRcSzTOBKqXmiwvxr8Ytwkd+YsaJzDVZ1nQhBVcaie5xAq/MdExH6ypmN8CkDHqik+wAH6+VPcDwaWTw5mmt437LtML8QJEreSdX6Gl+PVuQfpxLZF8ZJwltsG1Tk0PlpyTUbuMTcWO3gI405AMvArwWfrkbQMd9KmDOwYJTuNHUrqO6/a40HmORVRyfu2+pOqac+5/S89Oc16h5ZfCQLzRSLuBx23e3VOd599xP/DSYdu12+bh6bxUu+dgo11p6q3XjlnYXlhkWgn4gVzLywYjNcxLxspmfvEItNzi7PymEsZO0GK0jx76OhEpq2GXXURWaHZuruTMyWRPQtjxvktAnw+MdJp6/mRqf/66cQ90+2U2jmREfyArDDGk3LZGB/btnYRhp5G4uUY0AQo7pPBWZYyZ5sVXwi+8keC7NYjuEODD+fvMge1C9dz1VPFnex8fpH91RHCJAlHJoJUrPI3xcoYbd56MNWAc76TYKSfsEnBOG1BV4WKOGN2uAvxA+fkEhVVp2QpY94d+hIHShT327v3faqAkoOctH+iyxBi+/ehoVnCMc0Dmj+vE12F1zUytX5pYJuznIt7wiHd2uKR4MhicpHCXUbnhxDAjc1qBZkJZVJl4ERXFW0tm9H/NA60h1qPKgt1rt5V1r0mEKRsfk7Xrmh4OCfYGKiEOZaXQftvl44+7GoCPvZGA20py44wETHu6A3twViNr71mx/bR2DjsPQq5z2EwGplY1wSmFI7PmDLIlHasSaBhdsuBbbJwqYRVRGEOE1UNRDm61ITZG5mP3fUaPWXhmcqk+93zoCXS/ZQ/6PM9NDZxzNzxAm3mfmqTZftpd73+dRu6Yf3riqxyEk+7lbqpQZWPqSKzX0gWDKPEUYB/eR5U1vz5jVBonXtPIBFGyMOUKb1p+X7lI/X7IN3D23HWBQdCROipow7qwAcgYjrny9BoKvlK/rwB62iRM1P7Ot5Tz8EMjgr2nR3uIYMTclbIqnbpeE+VHgVkGRhVcUIaM8ecX0XPnvbz3p+1u7neW0z1TgS46LXwwRuY7lRbVaaWUCEzj3RMLqZBNLWKX9sctGW5mhRTxLiC2yoj8KsrTEWj6VlghTuXRgwNuSpbkL2HUjIXoQ7OWuPchk6/eU4lGFLXKRSWU2F9G5T6NM4Su9qyX1CXTqFVyiNIHwpZXQL67Z1bmSYj7C1932/dh6oYKXCzK6y0MoxhB6ffkC3nPqyL/E4OHKMjJnttD2N6FgxBwfj2c22+6NsdZOByPUVsemzfbflFcHzc6GnaADzZNVxUo1AxJWftFucQs/9LhLm6s2xqmR84JZT8mRUHnlnarGqMx7AUvAehtjGoglmAjWUKs40QVjA0uWazCZwiC1TbYoLji0t+zxQ+6fdkT0KzTCIHCTXE0yHp7m0FHBuOaRbBt5KNrN6XKRnX//uPsXwaSg8dgSKXpPaetU1y0EDmjxvW/cpkKQbJ6lF9plNacUNTMJeGbZnclaNAq/SFtHX/eS+VrUR8cIfQXM/UQvsGrhDvg0GNiOJ60mJZApc/L+xBZKtysI3qXRW7iHg5HkyTrP0VOfmVcXVDL1gw0Kk2rHW/U1Tzw0AYJeo1/GSsXnQmBM4jEuKAb0LC6q4IMfrFoZC8u7ZxnnSnjLEkeCceZFgRjRif35/8/f9MsMroI9mrjqkgiX0mS9wsi/KNrTEhfqZRbzQJmVdd87Ua7zygPz4E6wES6eZj21A+G3TygLxLZx2WBdPYLn8NGO8dYs6cyssUMdkTP57i2RVfPKQ3bGdaEaIGsvsQ8AM0Q0+paItXv9JA9VEDs1PPPbGN3wiN2gf8PSduBNhrIP8E+XEampu4EY95ZJwth/RVgXtiN0rBF3cgUXnhgYbqLxBhUxvUWikZPT8ZkFFwSDzYTDwSIowgXMcIDaLrKw+DKspWOMMvFORWdiEkxLzQLFCKxqHtdErRPBkxltY65Gm+3lSHDr9pseOFcYl1tAaYWvd01vZ6+U1eORux7UHgy5FPinvaGCfg+rdcCO2EPfrhlCIPuZmoiOXZLZ4FTg8DjpGWwQa3Eg3HVXNgNjDmrKHTPOsekyzRIxylRa0iqvyihpCLloOBsbbUekgTMk45oAsQ2/jHq2EzWYxUcE/nvm7jE6KwblcrLjQPi067gW9ZyoYhPPTPIeOeU0C+GHFAftYTjuWLs82Fy9MR2qUiBGRdiqs8tWZKlpFRHGu61+gME12xx2CMmUE/yPCXnFrfAhfx0E6SOhLP9W4tqhKkWng+98sbLN+5dIIWF3aXkbR9cyNaAiPZeUWi3Voar9NRi5qfmYTbV3LSyoA8QDHuMQqKR+vK+LivMschDdDEARXs47Ejf4S8dRAA/tJTUri6o5JjhfkWhKPF0W7oi5zkkrdCREiPL7HHL52syrIhfjJAWTserxhaCjuS0DfGbzXs+eLjU1HmqYWkFZnY4DlwlkKQla1bZC8Y24phX2vy7hlRXw3VQu53Ul3y/i65rykl7RUDRZdxIJT616xQ0GevR192LE3YiVtx7j8qrgBf7bhVwv6E+KSlYA5g==', NULL, 0, 0, '2018-02-08 20:31:35', '2018-02-09 08:48:38'),
(90, 3, 20180102, 2018, 1, 2, 6, 'jWHyZ1ttT2EDM3Mjgf0L1UdvKXjVswONMAbcxgY+IUQ6jSkIcHcot5+9kXP18YjmP64b87lvwCclL8s/bNVrrw==', NULL, 0, 0, '2018-02-08 20:38:09', '2018-02-08 20:38:09'),
(91, 3, 20180213, 2018, 2, 13, 5, '2AZC6NBv7535rU5JsbZoe7JyQZ3/5R/oqIXkKjNmqlSyUK1QZqLRz2E6qPiyLq6CY/Es3bGVkZGlH31OuV6gow==', NULL, 0, 0, '2018-02-13 18:53:46', '2018-02-13 18:53:46'),
(92, 3, 20180103, 2018, 1, 3, 6, 'k4tli18dyMlhYLG6MHYp/1xsb5dulTEmP/81fd/QLQZxp8dkKCnSt1wZKda3IykzwhUcaq1Lg2aHXzKcQe22ng==', NULL, 0, 0, '2018-02-20 07:13:53', '2018-02-20 07:13:53'),
(93, 3, 20180104, 2018, 1, 4, 5, 'j0mxMEXTHa0vn/kv6JdaGYI1fxG9zmkkxeqek+NLxSfKhBlcpeBmCp/ffdrIrh82923l9ZIreShg2Aqal34VlQ==', NULL, 0, 0, '2018-04-14 12:08:55', '2018-04-14 12:08:55'),
(94, 3, 20180414, 2018, 4, 14, 4, 'QKfQ5mIILWXF7+FRQMdlNlvzOlL/EjEhhAbX3QSHLHK/2+FfB3J7zui+NJOn/+b2Bs6WF1E4OkyEmKH+0Bxy2A==', NULL, 0, 0, '2018-04-14 12:13:27', '2018-04-14 12:13:27'),
(95, 2, 20180415, 2018, 4, 15, 5, 'Z4tmDOFaImcHaLz730aS5ugdQ3IPxlEAiCbtZMVA+mKIjMJKUx1OzENbfkS7dbQGof/nD9EhnDBt3WthJpfs7A==', NULL, 0, 0, '2018-04-15 11:17:29', '2018-04-15 11:17:29'),
(96, 2, 20180416, 2018, 4, 16, 6, 't44xHANffA+v+8feDRmQ/iEhuvCVPKikPd2HfqWdIKw=', NULL, 0, 0, '2018-04-21 11:27:39', '2018-04-21 11:27:39'),
(97, 2, 20180417, 2018, 4, 17, 7, 'mb8n4OplpEZqwWY8ZxEfMUEMF9H2m22N0UMOAvPCKIyJ2hKQhZI5L1z5Xvx2DGEAG7r3Aotgh9peTTEIL+stYw==', NULL, 0, 0, '2018-04-21 11:28:19', '2018-04-21 11:28:19'),
(98, 2, 20180418, 2018, 4, 18, 7, 'k0gSE11SYrhjHzd4qcyK3qLH3FYUmaT+c6utKd+KQwsxinJh3078531zNp0VIc3TAuw05FgThSCFhBDyzfCbXv7zbX/J41SxLlpcrz9I2IMJf5UQoea3b29pCcGd1tsh', NULL, 0, 0, '2018-04-21 12:04:39', '2018-04-21 12:04:39'),
(99, 2, 20180102, 2018, 1, 2, 6, 'Vt8N0jtfbCi5F0pzxQvculreyZMe285e37Z5b0d7lGBZh8ZCVtabv+2YAnbN4TwHbMyC3XmL5G+LI21hpwtMCA==', NULL, 0, 0, '2018-04-22 11:48:54', '2018-04-22 11:48:54'),
(100, 1, 20200202, 2018, 2, 2, 6, 'BF8taCZYeiYRJunLpEGu8P9pbYXpv0SbkeG2S2KNdNE=', NULL, 0, 0, '2020-08-13 15:10:33', '2020-08-13 15:21:33'),
(101, 1, 20200813, 2018, 8, 13, 5, 'KgEOyJyczxHDc6PlDPEF85bPTl+87/hbL0ZmtrJivd6/m3ghGKQ6O5biz3GMh8JD0hCTlv8TNjQ/We6yAJMeQA==', NULL, 0, 0, '2020-08-13 15:59:22', '2020-08-13 15:59:22'),
(102, 1, 20200410, 2020, 4, 10, 3, '+TQAuekRx4DTtpHa/OcIlG8lTw8hAY03uSabMDId4kK6PXh8b0H7FwU2gaN32IjNwjCKR+fGculGiJ486vwWxA==', NULL, 0, 0, '2020-08-13 16:00:31', '2020-08-13 16:00:31'),
(103, 1, 20200409, 2020, 4, 9, 7, 'iMt2J1dlimOYLhxa1qLcipFbazn77IfSp1yMtau+/aKanXvNaeV8CB6ydmNK7zv24FfBxIcAKeLv8iIQvUW+4g==', NULL, 0, 0, '2020-08-18 11:41:51', '2020-08-18 11:41:51'),
(104, 3, 20200818, 2020, 8, 18, 6, 'Rkd4t7AYoPDhEU1xeCFlPgpMkU87Czo7NK9YtQtBVBe90bXiFwsesExZxwqUyJCb8sgui4ZSe/9SifmcNYn/NAuh4yS7xbU+X1KJxeZguIHf7mjCbCspnlLP61CQQvGBTy0QlnwMCjGj8S7t+G30MF2e36L9e9wgBDR7zd2hM6k19fXAoppPHjpukrVIANzrEUq2ocNqs+WD11xw05eaiw==', NULL, 0, 0, '2020-08-18 15:18:08', '2020-08-19 15:27:24'),
(105, 3, 20190101, 2019, 1, 1, 7, 'cGQYoFGd1DWjw6zHaaselIoLI/KlK7rfAvs5XJXz/8I=', NULL, 0, 0, '2020-08-18 15:39:35', '2020-08-18 15:39:35'),
(106, 3, 20190102, 2019, 1, 2, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:39:38', '2020-08-18 15:39:38'),
(107, 3, 20190103, 2019, 1, 3, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:39:40', '2020-08-18 15:39:40'),
(108, 3, 20190104, 2019, 1, 4, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:39:43', '2020-08-18 15:39:43'),
(109, 3, 20190105, 2019, 1, 5, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:39:45', '2020-08-18 15:39:45'),
(110, 3, 20190106, 2019, 1, 6, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:39:49', '2020-08-18 15:39:49'),
(111, 3, 20190107, 2019, 1, 7, 1, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:39:52', '2020-08-18 15:39:52'),
(112, 3, 20190108, 2019, 1, 8, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:39:55', '2020-08-18 15:39:58'),
(113, 3, 20190109, 2019, 1, 9, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:02', '2020-08-18 15:40:02'),
(114, 3, 20190110, 2019, 1, 10, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:06', '2020-08-18 15:40:06'),
(115, 3, 20190111, 2019, 1, 11, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:10', '2020-08-18 15:40:10'),
(116, 3, 20190112, 2019, 1, 12, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:14', '2020-08-18 15:40:14'),
(117, 3, 20190113, 2019, 1, 13, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:17', '2020-08-18 15:40:17'),
(118, 3, 20190114, 2019, 1, 14, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:23', '2020-08-18 15:40:23'),
(119, 3, 20190115, 2019, 1, 15, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:27', '2020-08-18 15:40:27'),
(120, 3, 20190116, 2019, 1, 16, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:30', '2020-08-18 15:40:30'),
(121, 3, 20190117, 2019, 1, 17, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:33', '2020-08-18 15:40:33'),
(122, 3, 20190118, 2019, 1, 18, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:37', '2020-08-18 15:40:37'),
(123, 3, 20190119, 2019, 1, 19, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:41', '2020-08-18 15:40:41'),
(124, 3, 20190120, 2019, 1, 20, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:45', '2020-08-18 15:40:45'),
(125, 3, 20190121, 2019, 1, 21, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:48', '2020-08-18 15:40:48'),
(126, 3, 20190122, 2019, 1, 22, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:52', '2020-08-18 15:40:52'),
(127, 3, 20190123, 2019, 1, 23, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:55', '2020-08-18 15:40:55'),
(128, 3, 20190124, 2019, 1, 24, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:40:58', '2020-08-18 15:40:58'),
(129, 3, 20190125, 2019, 1, 25, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:41:01', '2020-08-18 15:41:01'),
(130, 3, 20190126, 2019, 1, 26, 1, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:41:04', '2020-08-18 15:41:04'),
(131, 3, 20190127, 2019, 1, 27, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:41:08', '2020-08-18 15:41:08'),
(132, 3, 20190128, 2019, 1, 28, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:41:12', '2020-08-18 15:41:12'),
(133, 3, 20190129, 2019, 1, 29, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:41:16', '2020-08-18 15:41:16'),
(134, 3, 20190130, 2019, 1, 30, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:41:20', '2020-08-18 15:41:20'),
(135, 3, 20190131, 2019, 1, 31, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:41:24', '2020-08-18 15:41:24'),
(136, 3, 20190201, 2019, 2, 1, 5, 'cGQYoFGd1DWjw6zHaaselIoLI/KlK7rfAvs5XJXz/8I=', NULL, 0, 0, '2020-08-18 15:47:52', '2020-08-18 15:47:52'),
(137, 3, 20190202, 2019, 2, 2, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:47:55', '2020-08-18 15:47:55'),
(138, 3, 20190203, 2019, 2, 3, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:47:59', '2020-08-18 15:47:59'),
(139, 3, 20190204, 2019, 2, 4, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:48:02', '2020-08-18 15:48:02'),
(140, 3, 20190205, 2019, 2, 5, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:48:05', '2020-08-18 15:48:05'),
(141, 3, 20190206, 2019, 2, 6, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:48:07', '2020-08-18 15:48:07'),
(142, 3, 20190207, 2019, 2, 7, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:48:10', '2020-08-18 15:48:10'),
(143, 3, 20190208, 2019, 2, 8, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:48:14', '2020-08-18 15:48:14'),
(144, 3, 20190209, 2019, 2, 9, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:48:18', '2020-08-18 15:48:18'),
(145, 3, 20190210, 2019, 2, 10, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:59:54', '2020-08-18 15:59:54'),
(146, 3, 20190211, 2019, 2, 11, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 15:59:57', '2020-08-18 15:59:57'),
(147, 3, 20190212, 2019, 2, 12, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:00:00', '2020-08-18 16:00:00'),
(148, 3, 20190213, 2019, 2, 13, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:00:03', '2020-08-18 16:00:03'),
(149, 3, 20190214, 2019, 2, 14, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:00:06', '2020-08-18 16:00:06'),
(150, 3, 20190215, 2019, 2, 15, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:07:04', '2020-08-18 16:07:04'),
(151, 3, 20190216, 2019, 2, 16, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:07:07', '2020-08-18 16:07:07'),
(152, 3, 20190218, 2019, 2, 18, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:07:10', '2020-08-18 16:07:10'),
(153, 3, 20190217, 2019, 2, 17, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:07:14', '2020-08-18 16:07:14'),
(154, 3, 20190219, 2019, 2, 19, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:10:45', '2020-08-18 16:10:45'),
(155, 3, 20190220, 2019, 2, 20, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:10:49', '2020-08-18 16:10:49'),
(156, 3, 20190221, 2019, 2, 21, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:10:54', '2020-08-18 16:10:54'),
(157, 3, 20190222, 2019, 2, 22, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:17:22', '2020-08-18 16:17:22'),
(158, 3, 20190223, 2019, 2, 23, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:17:35', '2020-08-18 16:17:35'),
(159, 3, 20190224, 2019, 2, 24, 6, 'cGQYoFGd1DWjw6zHaaselIoLI/KlK7rfAvs5XJXz/8I=', NULL, 0, 0, '2020-08-18 16:18:19', '2020-08-18 16:18:19'),
(160, 3, 20190225, 2019, 2, 25, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:18:22', '2020-08-18 16:18:22'),
(161, 3, 20190226, 2019, 2, 26, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:18:25', '2020-08-18 16:18:25'),
(162, 3, 20190227, 2019, 2, 27, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:18:28', '2020-08-18 16:18:28'),
(163, 3, 20190228, 2019, 2, 28, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:18:32', '2020-08-18 16:18:32'),
(164, 3, 20190301, 2019, 3, 1, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:18:53', '2020-08-18 16:18:53'),
(165, 3, 20190302, 2019, 3, 2, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:19:05', '2020-08-18 16:19:05'),
(166, 3, 20190303, 2019, 3, 3, 6, 'cGQYoFGd1DWjw6zHaaselIoLI/KlK7rfAvs5XJXz/8I=', NULL, 0, 0, '2020-08-18 16:22:08', '2020-08-18 16:22:08'),
(167, 3, 20190304, 2019, 3, 4, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:22:12', '2020-08-18 16:22:20'),
(168, 3, 20190305, 2019, 3, 5, 4, 'cGQYoFGd1DWjw6zHaaselIoLI/KlK7rfAvs5XJXz/8I=', NULL, 0, 0, '2020-08-18 16:23:08', '2020-08-18 16:23:08'),
(169, 3, 20190306, 2019, 3, 6, 5, 'cGQYoFGd1DWjw6zHaaselIoLI/KlK7rfAvs5XJXz/8I=', NULL, 0, 0, '2020-08-18 16:23:21', '2020-08-18 16:23:21'),
(170, 3, 20190307, 2019, 3, 7, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:23:24', '2020-08-18 16:23:24'),
(171, 3, 20190308, 2019, 3, 8, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:23:27', '2020-08-18 16:23:27'),
(172, 3, 20190309, 2019, 3, 9, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:23:42', '2020-08-18 16:23:42'),
(173, 3, 20190310, 2019, 3, 10, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:23:49', '2020-08-18 16:23:49'),
(174, 3, 20190311, 2019, 3, 11, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:23:59', '2020-08-18 16:23:59'),
(175, 3, 20190312, 2019, 3, 12, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:24:06', '2020-08-18 16:24:06'),
(176, 3, 20190313, 2019, 3, 13, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:24:11', '2020-08-18 16:24:11'),
(177, 3, 20190314, 2019, 3, 14, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:25:11', '2020-08-18 16:25:11'),
(178, 3, 20190315, 2019, 3, 15, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:25:28', '2020-08-18 16:25:28'),
(179, 3, 20190316, 2019, 3, 16, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:25:32', '2020-08-18 16:25:32'),
(180, 3, 20190317, 2019, 3, 17, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:25:36', '2020-08-18 16:25:36'),
(181, 3, 20190318, 2019, 3, 18, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:26:14', '2020-08-18 16:26:14'),
(182, 3, 20190319, 2019, 3, 19, 5, 'cGQYoFGd1DWjw6zHaaselIoLI/KlK7rfAvs5XJXz/8I=', NULL, 0, 0, '2020-08-18 16:27:06', '2020-08-18 16:27:06'),
(183, 3, 20190320, 2019, 3, 20, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:08', '2020-08-18 16:27:08'),
(184, 3, 20190321, 2019, 3, 21, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:10', '2020-08-18 16:27:17'),
(185, 3, 20190322, 2019, 3, 22, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:19', '2020-08-18 16:27:23'),
(186, 3, 20190323, 2019, 3, 23, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:26', '2020-08-18 16:27:26'),
(187, 3, 20190324, 2019, 3, 24, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:29', '2020-08-18 16:27:29'),
(188, 3, 20190325, 2019, 3, 25, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:32', '2020-08-18 16:27:32'),
(189, 3, 20190326, 2019, 3, 26, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:35', '2020-08-18 16:27:35'),
(190, 3, 20190327, 2019, 3, 27, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:38', '2020-08-18 16:27:38'),
(191, 3, 20190328, 2019, 3, 28, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:40', '2020-08-18 16:27:40'),
(192, 3, 20190329, 2019, 3, 29, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:42', '2020-08-18 16:27:42'),
(193, 3, 20190330, 2019, 3, 30, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:45', '2020-08-18 16:27:45'),
(194, 3, 20190331, 2019, 3, 31, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:47', '2020-08-18 16:27:47'),
(195, 3, 20190401, 2019, 4, 1, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:51', '2020-08-18 16:27:51'),
(196, 3, 20190402, 2019, 4, 2, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:53', '2020-08-18 16:27:53'),
(197, 3, 20190503, 2019, 5, 3, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:56', '2020-08-18 16:27:56'),
(198, 3, 20190403, 2019, 4, 3, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:27:58', '2020-08-18 16:27:58'),
(199, 3, 20190404, 2019, 4, 4, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:09', '2020-08-18 16:28:09'),
(200, 3, 20190405, 2019, 4, 5, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:12', '2020-08-18 16:28:12'),
(201, 3, 20190406, 2019, 4, 6, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:15', '2020-08-18 16:28:15'),
(202, 3, 20190407, 2019, 4, 7, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:17', '2020-08-18 16:28:17'),
(203, 3, 20190408, 2019, 4, 8, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:19', '2020-08-18 16:28:19'),
(204, 3, 20190409, 2019, 4, 9, 1, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:22', '2020-08-18 16:28:22'),
(205, 3, 20190410, 2019, 4, 10, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:24', '2020-08-18 16:28:24'),
(206, 3, 20190411, 2019, 4, 11, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:27', '2020-08-18 16:28:27'),
(207, 3, 20190412, 2019, 4, 12, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:29', '2020-08-18 16:28:29'),
(208, 3, 20190413, 2019, 4, 13, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:32', '2020-08-18 16:28:32'),
(209, 3, 20190414, 2019, 4, 14, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:35', '2020-08-18 16:28:35'),
(210, 3, 20190415, 2019, 4, 15, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:37', '2020-08-18 16:28:37'),
(211, 3, 20190416, 2019, 4, 16, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:40', '2020-08-18 16:28:40'),
(212, 3, 20190417, 2019, 4, 17, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:43', '2020-08-18 16:28:43'),
(213, 3, 20190418, 2019, 4, 18, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:28:46', '2020-08-18 16:28:46'),
(214, 3, 20190419, 2019, 4, 19, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:32', '2020-08-18 16:29:32'),
(215, 3, 20190420, 2019, 4, 20, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:35', '2020-08-18 16:29:35'),
(216, 3, 20190421, 2019, 4, 21, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:37', '2020-08-18 16:29:37'),
(217, 3, 20190422, 2019, 4, 22, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:40', '2020-08-18 16:29:42'),
(218, 3, 20190423, 2019, 4, 23, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:45', '2020-08-18 16:29:45'),
(219, 3, 20190424, 2019, 4, 24, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:47', '2020-08-18 16:29:47'),
(220, 3, 20190425, 2019, 4, 25, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:51', '2020-08-18 16:29:51'),
(221, 3, 20190426, 2019, 4, 26, 1, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:53', '2020-08-18 16:29:53'),
(222, 3, 20190427, 2019, 4, 27, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:55', '2020-08-18 16:29:55'),
(223, 3, 20190428, 2019, 4, 28, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:29:58', '2020-08-18 16:29:58'),
(224, 3, 20190429, 2019, 4, 29, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:00', '2020-08-18 16:30:00'),
(225, 3, 20190430, 2019, 4, 30, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:03', '2020-08-18 16:30:03'),
(226, 3, 20190501, 2019, 5, 1, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:06', '2020-08-18 16:30:06'),
(227, 3, 20190502, 2019, 5, 2, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:09', '2020-08-18 16:30:09'),
(228, 3, 20190504, 2019, 5, 4, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:12', '2020-08-18 16:30:12'),
(229, 3, 20190505, 2019, 5, 5, 1, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:14', '2020-08-18 16:30:14'),
(230, 3, 20190506, 2019, 5, 6, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:17', '2020-08-18 16:30:17'),
(231, 3, 20190507, 2019, 5, 7, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:19', '2020-08-18 16:30:19'),
(232, 3, 20190508, 2019, 5, 8, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:22', '2020-08-18 16:30:22'),
(233, 3, 20190509, 2019, 5, 9, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:24', '2020-08-18 16:30:24'),
(234, 3, 20190510, 2019, 5, 10, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:26', '2020-08-18 16:30:26'),
(235, 3, 20190511, 2019, 5, 11, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:28', '2020-08-18 16:30:28'),
(236, 3, 20190512, 2019, 5, 12, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:30', '2020-08-18 16:30:30'),
(237, 3, 20190513, 2019, 5, 13, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:33', '2020-08-18 16:30:33'),
(238, 3, 20190514, 2019, 5, 14, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:35', '2020-08-18 16:30:35'),
(239, 3, 20190515, 2019, 5, 15, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:38', '2020-08-18 16:30:38'),
(240, 3, 20190516, 2019, 5, 16, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:46', '2020-08-18 16:30:46'),
(241, 3, 20190517, 2019, 5, 17, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:49', '2020-08-18 16:30:49'),
(242, 3, 20190518, 2019, 5, 18, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:51', '2020-08-18 16:30:51'),
(243, 3, 20190519, 2019, 5, 19, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:54', '2020-08-18 16:30:54'),
(244, 3, 20190520, 2019, 5, 20, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:56', '2020-08-18 16:30:56'),
(245, 3, 20190521, 2019, 5, 21, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:30:59', '2020-08-18 16:30:59'),
(246, 3, 20190522, 2019, 5, 22, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:01', '2020-08-18 16:31:01'),
(247, 3, 20190523, 2019, 5, 23, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:04', '2020-08-18 16:31:04'),
(248, 3, 20190524, 2019, 5, 24, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:06', '2020-08-18 16:31:06'),
(249, 3, 20190525, 2019, 5, 25, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:09', '2020-08-18 16:31:09'),
(250, 3, 20190526, 2019, 5, 26, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:12', '2020-08-18 16:31:12'),
(251, 3, 20190527, 2019, 5, 27, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:14', '2020-08-18 16:31:14'),
(252, 3, 20190528, 2019, 5, 28, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:16', '2020-08-18 16:31:16'),
(253, 3, 20190529, 2019, 5, 29, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:19', '2020-08-18 16:31:19'),
(254, 3, 20190530, 2019, 5, 30, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:21', '2020-08-18 16:31:21'),
(255, 3, 20190531, 2019, 5, 31, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-18 16:31:24', '2020-08-18 16:31:24'),
(256, 3, 20180415, 2018, 4, 15, 5, 'JifwBLLPGzsD6eXkmkY0RDMkt8GlnoxUuQ3BYTIV1GE=', NULL, 0, 0, '2020-08-19 09:27:58', '2020-08-19 09:27:58'),
(257, 3, 20200817, 2020, 8, 17, 3, '+xKlA+eBdrpEL8orF6oL4p2lbLMFjkEyO5mbh9zPVZoJTgii4qNHs0bUK9iEMa4ffRw0OBL2H3RVqDqDATebn68Aqk+nMwRM/k02LxrJMsIQbBUh8SJx9rPT4t17+IHcOR5GXddbsudSIO/P23mxMHiZi9nETVnq0fz6RjN2BbQ=', NULL, 0, 0, '2020-08-19 15:18:16', '2020-08-19 15:18:16'),
(258, 3, 20200819, 2020, 8, 19, 5, 'Z4tmDOFaImcHaLz730aS5ugdQ3IPxlEAiCbtZMVA+mI=', NULL, 0, 0, '2020-08-19 16:59:34', '2020-08-19 16:59:34'),
(259, 3, 20190601, 2019, 6, 1, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:33:22', '2020-08-19 17:33:22'),
(260, 3, 20190602, 2019, 6, 2, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:33:25', '2020-08-19 17:33:25'),
(261, 3, 20190603, 2019, 6, 3, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:33:27', '2020-08-19 17:33:27'),
(262, 3, 20190604, 2019, 6, 4, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:01', '2020-08-19 17:34:01'),
(263, 3, 20190605, 2019, 6, 5, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:04', '2020-08-19 17:34:04'),
(264, 3, 20190606, 2019, 6, 6, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:06', '2020-08-19 17:34:06'),
(265, 3, 20190607, 2019, 6, 7, 6, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:09', '2020-08-19 17:34:09'),
(266, 3, 20190608, 2019, 6, 8, 7, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:12', '2020-08-19 17:34:12'),
(267, 3, 20190609, 2019, 6, 9, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:14', '2020-08-19 17:34:14'),
(268, 3, 20190610, 2019, 6, 10, 4, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:16', '2020-08-19 17:34:16'),
(269, 3, 20190611, 2019, 6, 11, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:18', '2020-08-19 17:34:18'),
(270, 3, 20190612, 2019, 6, 12, 5, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:21', '2020-08-19 17:34:21'),
(271, 3, 20190613, 2019, 6, 13, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:23', '2020-08-19 17:34:23'),
(272, 3, 20190614, 2019, 6, 14, 2, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:25', '2020-08-19 17:34:25'),
(273, 3, 20190615, 2019, 6, 15, 3, 'jKxnmH3xqsdSioyx/GPynMDO1Cj8V3fm7rExfbNAywE=', NULL, 0, 0, '2020-08-19 17:34:28', '2020-08-19 17:34:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `yin`
--
ALTER TABLE `yin`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `yin`
--
ALTER TABLE `yin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=274;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
